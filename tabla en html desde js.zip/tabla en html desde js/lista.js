let comidas= ["Pan", "Arroz","Huevos", "Carne", "Pescado"]
let lista=document.querySelector('#comidas')
lista.innerHTML=comidas