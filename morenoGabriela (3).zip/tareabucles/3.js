let suma=0
let i=3
do{
    suma=suma+i
    i=i+3
} while (i<=10000)
console.log(suma)
alert (suma)

