let s=0
let o=5
do{
    s=s+o
    o=o+5
} while (o<=10000)
console.log(s)
alert (s)
